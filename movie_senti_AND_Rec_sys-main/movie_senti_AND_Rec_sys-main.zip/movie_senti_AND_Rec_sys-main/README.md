# movie-sentiment-analysis
🚀 Movie Sentiment &amp; Recommendation System is a Streamlit-powered web application that analyzes movie reviews, provides AI-generated summaries, and recommends similar movies based on genre. It also allows users to analyze sentiment from text or uploaded images 
